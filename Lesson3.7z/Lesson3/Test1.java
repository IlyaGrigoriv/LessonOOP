package org.example.Repeat.Lesson3;

public class Test1 {
    public static void main(String[] args) {
        int teacher = 3;
        int study = 10;

        int resault = study % teacher;
        System.out.println(resault);
    }
}
