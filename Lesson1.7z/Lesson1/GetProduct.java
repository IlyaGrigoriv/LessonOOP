package org.example.Repeat.Lesson1;

public interface GetProduct {
    public Product getProduct();
}
