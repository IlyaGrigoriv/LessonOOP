package org.example.Repeat.Lesson1;

public enum Status {
    Холодный, горячий
}
